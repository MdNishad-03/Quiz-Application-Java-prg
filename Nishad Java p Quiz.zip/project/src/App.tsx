import React from 'react';
import { QuizProvider, useQuiz } from './context/QuizContext';
import StartScreen from './components/StartScreen';
import QuestionCard from './components/QuestionCard';
import ResultScreen from './components/ResultScreen';
import ProgressBar from './components/ProgressBar';
import Timer from './components/Timer';

function QuizApp() {
  const { state, dispatch } = useQuiz();
  const { quizStarted, quizFinished, questions } = state;
  
  const handleNextQuestion = () => {
    dispatch({ type: 'NEXT_QUESTION' });
  };
  
  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {!quizStarted && <StartScreen />}
        
        {quizStarted && !quizFinished && questions.length > 0 && (
          <div className="space-y-6">
            <ProgressBar />
            <Timer />
            <QuestionCard onNext={handleNextQuestion} />
          </div>
        )}
        
        {quizFinished && <ResultScreen />}
      </div>
    </div>
  );
}

function App() {
  return (
    <QuizProvider>
      <QuizApp />
    </QuizProvider>
  );
}

export default App;