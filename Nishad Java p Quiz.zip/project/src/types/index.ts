export interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number;
  difficulty: 'easy' | 'medium' | 'hard';
  timeLimit: number; // in seconds
}

export interface QuizState {
  questions: Question[];
  currentQuestionIndex: number;
  score: number;
  answers: (number | null)[];
  quizStarted: boolean;
  quizFinished: boolean;
  selectedDifficulty: 'all' | 'easy' | 'medium' | 'hard';
  timeRemaining: number | null;
}

export type QuizAction =
  | { type: 'START_QUIZ'; payload: { difficulty: 'all' | 'easy' | 'medium' | 'hard' } }
  | { type: 'ANSWER_QUESTION'; payload: { answerIndex: number } }
  | { type: 'NEXT_QUESTION' }
  | { type: 'TIMER_TICK' }
  | { type: 'TIMER_EXPIRED' }
  | { type: 'RESTART_QUIZ' };