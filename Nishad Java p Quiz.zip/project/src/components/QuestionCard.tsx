import React, { useState } from 'react';
import { useQuiz } from '../context/QuizContext';
import { CheckCircle, XCircle, AlertCircle } from 'lucide-react';

interface QuestionCardProps {
  onNext: () => void;
}

const QuestionCard: React.FC<QuestionCardProps> = ({ onNext }) => {
  const { state, dispatch } = useQuiz();
  const { questions, currentQuestionIndex, answers } = state;
  const currentQuestion = questions[currentQuestionIndex];
  
  const [selectedOption, setSelectedOption] = useState<number | null>(
    answers[currentQuestionIndex] === -1 ? null : answers[currentQuestionIndex]
  );
  const [showFeedback, setShowFeedback] = useState(false);
  
  const isAnswered = answers[currentQuestionIndex] !== null;
  const isTimeExpired = answers[currentQuestionIndex] === -1;
  
  const handleOptionSelect = (index: number) => {
    if (showFeedback || isAnswered) return;
    
    setSelectedOption(index);
  };
  
  const handleSubmit = () => {
    if (selectedOption === null) return;
    
    dispatch({
      type: 'ANSWER_QUESTION',
      payload: { answerIndex: selectedOption }
    });
    
    setShowFeedback(true);
  };
  
  const handleNextQuestion = () => {
    setSelectedOption(null);
    setShowFeedback(false);
    onNext();
  };
  
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-success-500';
      case 'medium': return 'text-warning-500';
      case 'hard': return 'text-error-500';
      default: return 'text-gray-500';
    }
  };
  
  if (!currentQuestion) return null;
  
  return (
    <div className="animate-fade-in w-full max-w-2xl mx-auto bg-white rounded-xl shadow-md overflow-hidden">
      <div className="p-6">
        <div className="flex justify-between items-center mb-4">
          <span className={`text-sm font-medium uppercase ${getDifficultyColor(currentQuestion.difficulty)}`}>
            {currentQuestion.difficulty}
          </span>
          <span className="text-sm font-medium text-gray-500">
            {currentQuestionIndex + 1}/{questions.length}
          </span>
        </div>
        
        <h2 className="text-xl font-bold text-gray-800 mb-6">{currentQuestion.text}</h2>
        
        <div className="space-y-3 mb-6">
          {currentQuestion.options.map((option, index) => {
            const isCorrect = index === currentQuestion.correctAnswer;
            const isSelected = selectedOption === index;
            let optionClassName = "p-4 border-2 rounded-lg cursor-pointer transition-all";
            
            if (showFeedback || isTimeExpired) {
              if (isCorrect) {
                optionClassName += " border-success-500 bg-success-50";
              } else if (isSelected) {
                optionClassName += " border-error-500 bg-error-50";
              } else {
                optionClassName += " border-gray-200 opacity-60";
              }
            } else {
              if (isSelected) {
                optionClassName += " border-primary-500 bg-primary-50";
              } else {
                optionClassName += " border-gray-200 hover:border-gray-300 hover:bg-gray-50";
              }
            }
            
            return (
              <div 
                key={index}
                className={optionClassName}
                onClick={() => handleOptionSelect(index)}
              >
                <div className="flex items-center">
                  <div className="flex-grow">
                    <p className="text-gray-800">{option}</p>
                  </div>
                  {showFeedback && isCorrect && (
                    <CheckCircle className="text-success-500 ml-2" size={20} />
                  )}
                  {showFeedback && isSelected && !isCorrect && (
                    <XCircle className="text-error-500 ml-2" size={20} />
                  )}
                </div>
              </div>
            );
          })}
        </div>
        
        {isTimeExpired && (
          <div className="flex items-center justify-center p-4 bg-error-50 border border-error-200 rounded-lg mb-6">
            <AlertCircle className="text-error-500 mr-2" size={20} />
            <p className="text-error-700">Time expired! The correct answer is highlighted.</p>
          </div>
        )}
        
        <div className="flex justify-end">
          {!showFeedback && !isTimeExpired ? (
            <button
              onClick={handleSubmit}
              disabled={selectedOption === null}
              className={`px-6 py-2 rounded-lg font-medium ${
                selectedOption === null
                  ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                  : 'bg-primary-600 text-white hover:bg-primary-700'
              }`}
            >
              Submit Answer
            </button>
          ) : (
            <button
              onClick={handleNextQuestion}
              className="px-6 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700"
            >
              Next Question
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default QuestionCard;