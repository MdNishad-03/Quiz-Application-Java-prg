import React, { useState } from 'react';
import { Brain } from 'lucide-react';
import { useQuiz } from '../context/QuizContext';

const StartScreen: React.FC = () => {
  const { dispatch } = useQuiz();
  const [selectedDifficulty, setSelectedDifficulty] = useState<'all' | 'easy' | 'medium' | 'hard'>('all');

  const handleStartQuiz = () => {
    dispatch({ 
      type: 'START_QUIZ', 
      payload: { difficulty: selectedDifficulty } 
    });
  };

  return (
    <div className="animate-fade-in text-center max-w-md w-full mx-auto">
      <div className="mb-8 flex justify-center">
        <div className="bg-primary-500 text-white p-4 rounded-full">
          <Brain size={48} />
        </div>
      </div>
      
      <h1 className="text-4xl font-bold text-gray-800 mb-4">QuizMaster</h1>
      <p className="text-gray-600 mb-8">
        Test your knowledge with our multiple-choice quiz. Select a difficulty level to get started!
      </p>

      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4 text-gray-700">Select Difficulty</h2>
        
        <div className="grid grid-cols-2 gap-4 mb-6">
          <button
            onClick={() => setSelectedDifficulty('all')}
            className={`px-4 py-3 rounded-lg transition-all ${
              selectedDifficulty === 'all'
                ? 'bg-primary-100 border-2 border-primary-500 text-primary-700'
                : 'bg-gray-100 border-2 border-gray-200 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All Levels
          </button>
          
          <button
            onClick={() => setSelectedDifficulty('easy')}
            className={`px-4 py-3 rounded-lg transition-all ${
              selectedDifficulty === 'easy'
                ? 'bg-success-50 border-2 border-success-500 text-success-700'
                : 'bg-gray-100 border-2 border-gray-200 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Easy
          </button>
          
          <button
            onClick={() => setSelectedDifficulty('medium')}
            className={`px-4 py-3 rounded-lg transition-all ${
              selectedDifficulty === 'medium'
                ? 'bg-warning-50 border-2 border-warning-500 text-warning-700'
                : 'bg-gray-100 border-2 border-gray-200 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Medium
          </button>
          
          <button
            onClick={() => setSelectedDifficulty('hard')}
            className={`px-4 py-3 rounded-lg transition-all ${
              selectedDifficulty === 'hard'
                ? 'bg-error-50 border-2 border-error-500 text-error-700'
                : 'bg-gray-100 border-2 border-gray-200 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Hard
          </button>
        </div>

        <button
          onClick={handleStartQuiz}
          className="w-full py-3 px-6 bg-primary-600 text-white rounded-lg font-semibold hover:bg-primary-700 transition-colors shadow-md hover:shadow-lg"
        >
          Start Quiz
        </button>
      </div>
      
      <p className="text-gray-500 text-sm">
        Answer questions within the time limit to earn points. Good luck!
      </p>
    </div>
  );
};

export default StartScreen;