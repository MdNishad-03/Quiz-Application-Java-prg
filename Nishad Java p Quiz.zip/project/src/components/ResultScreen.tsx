import React from 'react';
import { useQuiz } from '../context/QuizContext';
import { Trophy, RefreshCw, CheckCircle, XCircle, Clock } from 'lucide-react';

const ResultScreen: React.FC = () => {
  const { state, dispatch } = useQuiz();
  const { questions, score, answers } = state;
  
  const percentage = Math.round((score / questions.length) * 100);
  
  const getResultMessage = () => {
    if (percentage >= 90) return "Outstanding! You're a quiz master!";
    if (percentage >= 70) return "Great job! You know your stuff!";
    if (percentage >= 50) return "Good effort! Keep learning!";
    return "Keep practicing! You'll get better!";
  };
  
  const getResultColor = () => {
    if (percentage >= 90) return "text-success-700";
    if (percentage >= 70) return "text-primary-700";
    if (percentage >= 50) return "text-warning-700";
    return "text-error-700";
  };
  
  const getAnswerIcon = (questionIndex: number) => {
    const answer = answers[questionIndex];
    const correctAnswer = questions[questionIndex].correctAnswer;
    
    if (answer === -1) {
      return <Clock className="text-warning-500 mr-2" size={18} />;
    }
    
    if (answer === correctAnswer) {
      return <CheckCircle className="text-success-500 mr-2" size={18} />;
    }
    
    return <XCircle className="text-error-500 mr-2" size={18} />;
  };
  
  const handleRestartQuiz = () => {
    dispatch({ type: 'RESTART_QUIZ' });
  };
  
  return (
    <div className="animate-fade-in max-w-2xl w-full mx-auto">
      <div className="bg-white rounded-xl shadow-md overflow-hidden mb-6">
        <div className="p-6 text-center">
          <div className="mb-4 flex justify-center">
            <div className="bg-primary-500 text-white p-4 rounded-full">
              <Trophy size={40} />
            </div>
          </div>
          
          <h2 className="text-3xl font-bold text-gray-800 mb-2">Quiz Complete!</h2>
          <p className={`text-xl font-medium mb-4 ${getResultColor()}`}>
            {getResultMessage()}
          </p>
          
          <div className="flex justify-center items-center mb-6">
            <div className="text-5xl font-bold text-primary-600 mr-4">{score}</div>
            <div className="text-xl text-gray-600">/ {questions.length}</div>
          </div>
          
          <div className="w-full bg-gray-200 rounded-full h-4 mb-6">
            <div 
              className={`h-4 rounded-full ${
                percentage >= 70 ? 'bg-success-500' : 
                percentage >= 40 ? 'bg-warning-500' : 
                'bg-error-500'
              }`}
              style={{ width: `${percentage}%` }}
            ></div>
          </div>
          
          <button
            onClick={handleRestartQuiz}
            className="inline-flex items-center px-6 py-3 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors shadow-md hover:shadow-lg"
          >
            <RefreshCw size={18} className="mr-2" />
            Try Again
          </button>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6">
          <h3 className="text-xl font-semibold text-gray-800 mb-4">Answer Review</h3>
          
          <div className="space-y-4">
            {questions.map((question, index) => {
              const userAnswer = answers[index];
              const isCorrect = userAnswer === question.correctAnswer;
              const isTimeExpired = userAnswer === -1;
              
              return (
                <div key={index} className="border-b border-gray-200 pb-4 last:border-b-0 last:pb-0">
                  <div className="flex items-start mb-2">
                    {getAnswerIcon(index)}
                    <h4 className="font-medium text-gray-800">{question.text}</h4>
                  </div>
                  
                  {isTimeExpired ? (
                    <div className="ml-6 text-warning-600">
                      <p>Time expired</p>
                      <p className="text-sm text-gray-600">
                        Correct answer: {question.options[question.correctAnswer]}
                      </p>
                    </div>
                  ) : (
                    <div className="ml-6">
                      {isCorrect ? (
                        <p className="text-success-600">
                          You answered: {question.options[userAnswer!]}
                        </p>
                      ) : (
                        <>
                          <p className="text-error-600">
                            You answered: {question.options[userAnswer!]}
                          </p>
                          <p className="text-sm text-gray-600">
                            Correct answer: {question.options[question.correctAnswer]}
                          </p>
                        </>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultScreen;