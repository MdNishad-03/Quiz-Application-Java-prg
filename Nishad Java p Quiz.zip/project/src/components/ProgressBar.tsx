import React from 'react';
import { useQuiz } from '../context/QuizContext';

const ProgressBar: React.FC = () => {
  const { state } = useQuiz();
  const { currentQuestionIndex, questions } = state;
  
  const progress = (currentQuestionIndex / questions.length) * 100;
  
  return (
    <div className="w-full mb-6">
      <div className="flex justify-between mb-1 text-sm text-gray-600">
        <span>Question {currentQuestionIndex + 1} of {questions.length}</span>
        <span>{Math.round(progress)}% complete</span>
      </div>
      <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
        <div 
          className="h-full bg-primary-500 transition-all duration-300 ease-in-out"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
};

export default ProgressBar;