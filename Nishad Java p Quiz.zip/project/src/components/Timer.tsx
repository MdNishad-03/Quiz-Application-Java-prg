import React, { useEffect, useState } from 'react';
import { Clock } from 'lucide-react';
import { useQuiz } from '../context/QuizContext';

const Timer: React.FC = () => {
  const { state } = useQuiz();
  const { timeRemaining } = state;
  const [isWarning, setIsWarning] = useState(false);
  
  useEffect(() => {
    if (timeRemaining !== null && timeRemaining <= 5) {
      setIsWarning(true);
    } else {
      setIsWarning(false);
    }
  }, [timeRemaining]);
  
  if (timeRemaining === null) return null;
  
  // Calculate percentage for visual timer
  const percentage = timeRemaining / state.questions[state.currentQuestionIndex].timeLimit * 100;
  
  return (
    <div className="mb-6">
      <div className="flex items-center justify-center mb-2">
        <Clock size={20} className={`mr-2 ${isWarning ? 'text-error-500' : 'text-gray-600'}`} />
        <span className={`font-medium ${isWarning ? 'text-error-500' : 'text-gray-600'} ${isWarning ? 'animate-pulse-slow' : ''}`}>
          {timeRemaining} seconds remaining
        </span>
      </div>
      
      <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
        <div 
          className={`h-full transition-all duration-300 ease-in-out ${
            isWarning ? 'bg-error-500' : 
            percentage > 50 ? 'bg-success-500' : 'bg-warning-500'
          }`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
};

export default Timer;