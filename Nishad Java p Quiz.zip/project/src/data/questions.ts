import { Question } from '../types';

export const questions: Question[] = [
  {
    id: 1,
    text: "What is React?",
    options: [
      "A JavaScript library for building user interfaces",
      "A programming language",
      "A database management system",
      "A server-side runtime environment"
    ],
    correctAnswer: 0,
    difficulty: "easy",
    timeLimit: 20
  },
  {
    id: 2,
    text: "Which of the following is NOT a JavaScript data type?",
    options: [
      "String",
      "Boolean",
      "Character",
      "Number"
    ],
    correctAnswer: 2,
    difficulty: "easy",
    timeLimit: 15
  },
  {
    id: 3,
    text: "What does CSS stand for?",
    options: [
      "Creative Style Sheets",
      "Computer Style Sheets",
      "Cascading Style Sheets",
      "Colorful Style Sheets"
    ],
    correctAnswer: 2,
    difficulty: "easy",
    timeLimit: 10
  },
  {
    id: 4,
    text: "Which hook is used to perform side effects in a React component?",
    options: [
      "useState",
      "useEffect",
      "useContext",
      "useReducer"
    ],
    correctAnswer: 1,
    difficulty: "medium",
    timeLimit: 20
  },
  {
    id: 5,
    text: "What does the `map` method do in JavaScript?",
    options: [
      "Modifies the original array",
      "Creates a new array with the results of calling a function on every element",
      "Filters out elements that don't match a condition",
      "Combines all elements into a single value"
    ],
    correctAnswer: 1,
    difficulty: "medium",
    timeLimit: 25
  },
  {
    id: 6,
    text: "What is the time complexity of binary search?",
    options: [
      "O(1)",
      "O(log n)",
      "O(n)",
      "O(n²)"
    ],
    correctAnswer: 1,
    difficulty: "hard",
    timeLimit: 30
  },
  {
    id: 7,
    text: "Which of the following is a closure in JavaScript?",
    options: [
      "A function that accepts another function as an argument",
      "A function that returns another function",
      "A function that has access to variables in its outer scope",
      "A function that modifies global variables"
    ],
    correctAnswer: 2,
    difficulty: "hard",
    timeLimit: 30
  },
  {
    id: 8,
    text: "What is the virtual DOM in React?",
    options: [
      "A direct copy of the browser's DOM",
      "A lightweight copy of the actual DOM in memory",
      "A virtual machine that runs JavaScript code",
      "A server-side rendering technique"
    ],
    correctAnswer: 1,
    difficulty: "medium",
    timeLimit: 25
  },
  {
    id: 9,
    text: "Which HTTP method is idempotent?",
    options: [
      "GET",
      "POST",
      "PATCH",
      "DELETE"
    ],
    correctAnswer: 0,
    difficulty: "hard",
    timeLimit: 25
  },
  {
    id: 10,
    text: "What is the output of `console.log(typeof [])`?",
    options: [
      "array",
      "object",
      "undefined",
      "null"
    ],
    correctAnswer: 1,
    difficulty: "medium",
    timeLimit: 20
  }
];