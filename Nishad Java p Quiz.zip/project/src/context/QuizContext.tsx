import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { QuizState, QuizAction, Question } from '../types';
import { questions } from '../data/questions';

const initialState: QuizState = {
  questions: [],
  currentQuestionIndex: 0,
  score: 0,
  answers: [],
  quizStarted: false,
  quizFinished: false,
  selectedDifficulty: 'all',
  timeRemaining: null,
};

function quizReducer(state: QuizState, action: QuizAction): QuizState {
  switch (action.type) {
    case 'START_QUIZ': {
      const { difficulty } = action.payload;
      const filteredQuestions = difficulty === 'all' 
        ? questions 
        : questions.filter(q => q.difficulty === difficulty);
      
      const randomizedQuestions = [...filteredQuestions].sort(() => Math.random() - 0.5);
      
      return {
        ...initialState,
        questions: randomizedQuestions,
        answers: Array(randomizedQuestions.length).fill(null),
        quizStarted: true,
        selectedDifficulty: difficulty,
        timeRemaining: randomizedQuestions.length > 0 ? randomizedQuestions[0].timeLimit : null,
      };
    }
    
    case 'ANSWER_QUESTION': {
      const { answerIndex } = action.payload;
      const currentQuestion = state.questions[state.currentQuestionIndex];
      const isCorrect = answerIndex === currentQuestion.correctAnswer;
      
      const newAnswers = [...state.answers];
      newAnswers[state.currentQuestionIndex] = answerIndex;
      
      return {
        ...state,
        score: isCorrect ? state.score + 1 : state.score,
        answers: newAnswers,
      };
    }
    
    case 'NEXT_QUESTION': {
      const nextIndex = state.currentQuestionIndex + 1;
      const isFinished = nextIndex >= state.questions.length;
      
      return {
        ...state,
        currentQuestionIndex: isFinished ? state.currentQuestionIndex : nextIndex,
        quizFinished: isFinished,
        timeRemaining: isFinished ? null : state.questions[nextIndex].timeLimit,
      };
    }
    
    case 'TIMER_TICK':
      if (state.timeRemaining === null || state.timeRemaining <= 0) {
        return state;
      }
      return {
        ...state,
        timeRemaining: state.timeRemaining - 1,
      };
    
    case 'TIMER_EXPIRED': {
      const nextIndex = state.currentQuestionIndex + 1;
      const isFinished = nextIndex >= state.questions.length;
      
      // If time expired, we move to next question without giving a point
      const newAnswers = [...state.answers];
      newAnswers[state.currentQuestionIndex] = -1; // -1 indicates time expired
      
      return {
        ...state,
        currentQuestionIndex: isFinished ? state.currentQuestionIndex : nextIndex,
        quizFinished: isFinished,
        timeRemaining: isFinished ? null : state.questions[nextIndex].timeLimit,
        answers: newAnswers,
      };
    }
    
    case 'RESTART_QUIZ':
      return initialState;
    
    default:
      return state;
  }
}

const QuizContext = createContext<{
  state: QuizState;
  dispatch: React.Dispatch<QuizAction>;
} | undefined>(undefined);

export function QuizProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(quizReducer, initialState);
  
  // Timer effect
  useEffect(() => {
    if (!state.quizStarted || state.quizFinished || state.timeRemaining === null) {
      return;
    }
    
    const timerId = setInterval(() => {
      if (state.timeRemaining <= 0) {
        dispatch({ type: 'TIMER_EXPIRED' });
        clearInterval(timerId);
      } else {
        dispatch({ type: 'TIMER_TICK' });
      }
    }, 1000);
    
    return () => clearInterval(timerId);
  }, [state.quizStarted, state.quizFinished, state.timeRemaining, state.currentQuestionIndex]);
  
  return (
    <QuizContext.Provider value={{ state, dispatch }}>
      {children}
    </QuizContext.Provider>
  );
}

export function useQuiz() {
  const context = useContext(QuizContext);
  if (context === undefined) {
    throw new Error('useQuiz must be used within a QuizProvider');
  }
  return context;
}